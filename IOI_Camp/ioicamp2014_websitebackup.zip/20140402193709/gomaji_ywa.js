// YWA instrumentation on GOMAJI TW
// Created by: Tsung-Yu Lee 
// Date: 2013/12/12
// Last edit by: Tsung-Yu
// Date: 2014/2/20
// Note: YCP migration

var proj = {pid: "1000473865585",
            region: "APAC",
            name: "GOMAJI TW"};

var beacons = {PC: "1197726972",
               Mobile: "1197726973",
               Local: "1197726974",                  
               Deliver : "1197726975",
               Travel: "1197726976",
               Ticket: "1197726977",
               DownloadApp: "1197726978",
               GetApp: "1197726979",
               Add_To_Cart: "1197726980",
               SubscribePage: "1197726981",
               Subscribe: "1197726982",
               LinkDownload: "1197726983",
               AppDownload: "1197726984",
               Billing_Conf: "1197726985",
               AppStore: "1197727023"};
var CF = {Platform: 7,  
          Subject: 8,
          Region: 9,
          City: 10,
          Cat: 11,
          Sub_Cat: 12,
          Promo: 13,
          Prod_Name: 14,
          SKU: 17,
          Tag_List: 18};
var actions = {SubscribePage: "20",
               Subscribe: "21",
               LinkDownload: "22",
               AppDownload: "23",
               BillingConf: "01",
               AppStore: "24"};

if(location.protocol == "https:")
	document.write("<script type='text/javascript' src='https://s.yimg.com/mi/apac/ywa.js'></script>");
else
	document.write("<script type='text/javascript' src='http://d.yimg.com/mi/apac/ywa.js'></script>");
if(typeof jQuery == "undefined")
  document.write("<script type='text/javascript' src='http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js'></script>");

var myDB = {
  region: {"1": "北部地區", "2": "中部地區", "3": "南部地區", "4": "花東地區"},
  category_id: {"1": "美食", "4": "美類", "10": "生活", "12": "美食饗宴", "13": "精品生活", "14": "3C家電",
                "15": "流行時尚", "16": "美妝保養", "17": "媽咪寶貝", "26": "展覽", "28": "遊樂", "29": "親子", "30": "傢俱傢飾"},
  tag_id: {"2": "中式料理", "6": "西式料理", "5": "日式料理", "4": "美式餐廳", "9": "義式料理", "7": "異國料理", "15": "吃到飽",
           "8": "咖啡輕食", "10": "甜點冰品", "33": "美容SPA", "32": "美髮", "37,39": "美甲美睫", "now": "即日起可用/即買即用"},
  sort: {"latest": "最新", "popularity": "熱門", "amount": "銷量"},
  city: {"Taiwan": "台灣", "Taipei": "台北", "Taichung": "台中", "Kaohsiung": "高雄", "Taoyuan": "桃園", "Tainan": "台南",
         "Hsinchu": "新竹", "Yilan": "宜蘭", "Keelung": "基隆", "Chiayi": "嘉義", "Pingtung": "屏東", "Changhua": "彰化",
         "Miaoli": "苗栗", "Nantou": "南投", "Hualien": "花蓮", "Yunlin": "雲林", "Taitung": "台東"}
}

/******                Functions                 ******/

function getTracker() {
  try {
    return YWA.getTracker(proj.pid, proj.region);
  } catch (eYWATCUnavailable) {
    if (window.console && window.console.warn) {
      window.console.warn(eYWATCUnavailable.message || "Unknown error");
    return;
    }
  }
}

function doBeacon(beacon) {
   var YHB=new Image();
   YHB.src="http://pclick.yahoo.com/p/s="+beacon+"&t="+Math.random();
}

function doYCP(pixType, cat, productId) {
  var typeToID = {"ProdPage": "2rl8c7sl"};
  var YCP = new Image(),
      base_url="https://s-pm-ap.dp.yahoo.com/PixelMonkey?pixelId="+ typeToID[pixType] +"&format=image&useReferrer=1&additionalParams=";  
  YCP.src = base_url + cat + "pid:" + productId;
}

function getURLVars(url) {
	var vars = {},
		hash;
	var hashes = url.slice(url.indexOf("?") + 1).split("&");
	for(var i=0; i<hashes.length; i++){
		hash = hashes[i].split("=");
		vars[hash[0]] = hash[1];
	}
	return vars;
}

function doYWA() {
   	var YWATracker = getTracker();
   	var url_tail = (document.URL.split(".com/")[1] === undefined)? document.URL : document.URL.split(".com/")[1];
    var url_vars = getURLVars(url_tail);

    var platform_str = "";
    if(document.domain === "m.gomaji.com" || document.domain === "mweb.gomaji.com"){
      platform_str = "Mobile";
    }else if(document.domain === "www.gomaji.com" || document.domain === "buy.gomaji.com"){
      platform_str = "PC";
    }

    var subject_str = "其他";
    var city_str = "";
    // 本地團購也有可能以地名的形式出現在url尾端. ex: www.gomaji.com/Taoyuan
    // 宅配購: www.gomaji.com/Taiwan
    if(url_tail.indexOf(".php") === -1 && url_tail.indexOf(".html") === -1 && url_tail.indexOf("instantdeal") === -1 && document.URL !== "http://m.gomaji.com"){
      if(url_tail === "Taiwan"){
        subject_str = "宅配購";
        city_str = "台灣";
      }else{
        subject_str = "本地團購";
        if(!url_vars.city){
          url_tail = url_tail.split("#")[0];
          city_str = (myDB["city"][url_tail] !== undefined)? myDB["city"][url_tail] : "Others";
        }
      }
    }else{
      if(url_tail.indexOf("index.php") !== -1){
        if(url_tail.indexOf("Taiwan") !== -1){
          subject_str = "宅配購";
          city_str = "台灣"
        }else{
          subject_str = "本地團購";
          // if(url_vars.city){
          //   city_str = (myDB["city"][url_vars.city] !== undefined)? myDB["city"][url_vars.city] : "Others";
          // }
        }
      }else if(url_tail.indexOf("travel.php") !== -1){
        subject_str = "一起旅行";
      }else if(url_tail.indexOf("ticket.php") !== -1){
        subject_str = "票！";
      }else if(url_tail.indexOf("event/201112/instantdeal") !== -1) {
        subject_str = "下載APP好康帶著走";
      }else if(url_tail.indexOf("deal-list.php") !== -1){
        subject_str = "過往團購";
      }else if(url_tail.indexOf("store-detail.php") !== -1 || url_tail.indexOf("yellowpage.php") !== -1){
        subject_str = "精選店家";
      }
    }
    if(url_vars.city){
      city_str = (myDB["city"][url_vars.city] !== undefined)? myDB["city"][url_vars.city] : "Others";
    }

    var region_str = "";
    if(url_vars.region){
      switch(url_vars.region){
        case "1":
          region_str = "北部地區";
          break;
        case "2":
          region_str = "中部地區";
          break;
        case "3":
          region_str = "南部地區";
          break;
        case "4":
          region_str = "花東地區";
          break;
        default:
          region_str = url_vars.region;
          break;
      }
    }

    var cat_str = "";
    // 即日起可用/即買即用 以tag_id分
    if(url_vars.category_id){
      switch(url_vars.category_id){
        case "1":
          cat_str = "美食";
          break;
        case "4":
          cat_str = "美類";
          break;
        case "10":
          cat_str = "生活";
          break;
        case "12":
          cat_str = "美食饗宴";
          break;
        case "13":
          cat_str = "精品生活";
          break;
        case "14":
          cat_str = "3C家電";
          break;
        case "15":
          cat_str = "流行時尚";
          break;
        case "16":
          cat_str = "美妝保養";
          break;
        case "17":
          cat_str = "媽咪寶貝";
          break;
        case "26":
          cat_str = "展覽";
          break;
        case "28":
          cat_str = "遊樂";
          break;
        case "29":
          cat_str = "親子";
          break;
        case "30":
          cat_str = "傢俱傢飾";
          break;
        default:
          cat_str = url_vars.category_id;
          break;
      }
    }

    var subcat_str = "";
    if(url_vars.tag_id){
      switch(url_vars.tag_id){
        case "2":
          cat_str = "美食";
          subcat_str = "中式料理";
          break;
        case "6":
          cat_str = "美食";
          subcat_str = "西式料理";
          break;
        case "5":
          cat_str = "美食";
          subcat_str = "日式料理";
          break;
        case "4":
          cat_str = "美食";
          subcat_str = "美式餐廳";
          break;
        case "9":
          cat_str = "美食";
          subcat_str = "義式料理";
          break;
        case "7":
          cat_str = "美食";
          subcat_str = "異國料理";
          break;
        case "15":
          cat_str = "美食";
          subcat_str = "吃到飽";
          break;
        case "8":
          cat_str = "美食";
          subcat_str = "咖啡輕食";
          break;
        case "10":
          cat_str = "美食";
          subcat_str = "甜點冰品";
          break;
        case "33":
          cat_str = "美類";
          subcat_str = "美容SPA";
          break;
        case "32":
          cat_str = "美類";
          subcat_str = "美髮";
          break;
        case "37,39":
          cat_str = "美類";
          subcat_str = "美甲美睫";
          break;
        case "now":
          cat_str = "即日起可用/即買即用";
          break;
        default:
          subcat_str = url_vars.tag_id;
          break;
      }
    }

    var promo_str = "";
    if(url_vars.sort){
      switch(url_vars.sort){
        case "latest":
          promo_str = "最新";
          break;
        case "popularity":
          promo_str = "熱門";
          break;
        case "amount":
          promo_str = "銷量";
          break;
        default:
          promo_str = url_vars.sort;
          break;
      }
    }

    // Product Name & SKU
    var sku = "";
    if(url_tail.indexOf(".html") !== -1){
      sku = (url_tail.split("_")[1] === undefined)? url_tail.split("p")[1].split(".html")[0] : url_tail.split("_")[1].split("p")[1].split(".html")[0];
    }else if(url_tail.indexOf("index-sub.php") !== -1 || url_tail.indexOf("deal.php") !== -1 || url_tail.indexOf("travel-sub.php") !== -1){
      if(url_vars.pid)
        sku = url_vars.pid;
    }
    if(/\d+/.test(sku)){
        // YWATracker.setCF(CF.Prod_Name, $('span.product-name').text());
      YWATracker.setCF(CF.SKU, sku);
      YWATracker.setSKU(sku);
      var tags = getURLVars(document.referrer);
      var tagList = "";
      var ycp_cats = "";
      for(key in tags) {
        if(tags[key] !== undefined){
          if(myDB[key] !== undefined){
            if(myDB[key][tags[key]] !== undefined)
              tagList += myDB[key][tags[key]] + "$";
            else
              tagList += key + ":" + tags[key] + "$";
          }
          if(key === "store_id")
            tagList += key + ":" + tags[key] + "$";
          ycp_cats += key + ":" + tags[key] + ";";            
        }
      }
      YWATracker.setCF(CF.Tag_List, tagList.substr(0, tagList.length - 1));
      YWATracker.setAction("PRODUCT_VIEW");
      doYCP("ProdPage", ycp_cats, sku);
      if($('span.product-name').text()){
        YWATracker.setCF(CF.Prod_Name, $('span.product-name').text());
      }
      subject_str = "商品頁";
    }

    YWATracker.setCF(CF.Platform, platform_str);
    YWATracker.setCF(CF.Subject, subject_str);
    YWATracker.setCF(CF.Region, region_str);
    YWATracker.setCF(CF.City, city_str);
    YWATracker.setCF(CF.Cat, cat_str);
    YWATracker.setCF(CF.Sub_Cat, subcat_str);
    YWATracker.setCF(CF.Promo, promo_str);

    YWATracker.submit();

    if(platform_str === "PC"){
      doBeacon(beacons.PC);
    }else if(platform_str === "Mobile"){
      doBeacon(beacons.Mobile);
    }

    if(subject_str !== "其他"){
      switch(subject_str){
        case "本地團購":
          doBeacon(beacons.Local);
          break;
        case "宅配購":
          doBeacon(beacons.Deliver);
          break;
        case "一起旅行":
          doBeacon(beacons.Travel);
          break;
        case "票！":
          doBeacon(beacons.Ticket);
          break;
        case "下載APP好康帶著走":
          doBeacon(beacons.DownloadApp);
          break;
      }
    }
}

function doStartBuy(productId) {
    var YWATracker = getTracker();
    YWATracker.setAction("ADD_TO_CART");
   	YWATracker.setSKU(productId);
    YWATracker.setCF(CF.SKU, productId);
    var tags = getURLVars(document.referrer);
    var tagList = "";
    for(key in tags) {
      if(tags[key] !== undefined){
        if(myDB[key] !== undefined)
          tagList += myDB[key][tags[key]] + "$";
        else
          tagList += key + ":" + tags[key] + "$";
      }
    }
    YWATracker.setCF(CF.Tag_List, tagList.substr(0, tagList.length - 1));
   	YWATracker.submit_action();
   	doBeacon(beacons.Add_To_Cart);
}

function doSubscribe(type) {
  var YWATracker = getTracker();
  switch(type){
    case "page":
      YWATracker.setAction(actions.SubscribePage);
      doBeacon(beacons.SubscribePage);
      break;
    case "confirm":
      YWATracker.setAction(actions.Subscribe);
      doBeacon(beacons.Subscribe);
      break;
  }
  YWATracker.submit_action();
}

function doDownload(type) {
  var YWATracker = getTracker();
  switch(type){
    case "PC":
      YWATracker.setAction(actions.LinkDownload);
      doBeacon(beacons.LinkDownload);
      break;
    case "MobileInstall":
      YWATracker.setAction(actions.AppDownload);
      doBeacon(beacons.AppDownload);
      break;
    case "MobileAppStore":
      YWATracker.setAction(actions.AppStore);
      doBeacon(beacons.AppStore);
      break;
  }
  YWATracker.submit_action();
}

function doBillingConfirm(orderId, productList, units, amounts, totalAmount) {
  var YWATracker = getTracker();
	YWATracker.setAction(actions.BillingConf);
	if(orderId)
		YWATracker.setOrderId(orderId);
	if(productList){
		YWATracker.setSKU(productList);
    YWATracker.setCF(CF.SKU, productList);
  }
	if(units)
		YWATracker.setUnits(units);
	if(amounts){
    YWATracker.setAmounts(amounts);
  }
	if(totalAmount) {
		totalAmount = "TWD" + totalAmount;
		YWATracker.setAmount(totalAmount);
	}
	YWATracker.submit_action();
	doBeacon(beacons.Billing_Conf);
  // doYCPConversion();
}

function doAppPage(){
  var YWATracker = getTracker();
  YWATracker.setCF(CF.Platform, "Mobile");
  YWATracker.setCF(CF.Subject, "取得GOMAJI應用程式");
  YWATracker.submit();
  doBeacon(beacons.GetApp);
}
