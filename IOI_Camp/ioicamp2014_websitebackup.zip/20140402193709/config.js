;(function(window) {
	var cmconfig = {
		'cm_url': 'https://tw-cm.ysm.yahoo.com/js_flat_1_0/?',
		'title': '市場快訊',
		'title_url': 'https://tw.ysm.emarketing.yahoo.com/soeasy/index.php',
		'title2': '搜便利找商家',
		'title_url2': 'ysm/evt=51199/*http://tw.ysm.emarketing.yahoo.com/soeasy/index.php'
	};
	
	var params = [
		{
			'ctxtUrl': 'tw.yahoo.com?wp01',
			'source': 'yahoo_tw_homepage_hp_cm_ron1',
			'Channel': 'DS'
		}, {
			'ctxtUrl': 'tw.yahoo.com?wp02',
			'source': 'yahoo_tw_homepage_hp_cm_ron2',
			'Channel': 'DS'
		}, {
			'ctxtUrl': 'tw.yahoo.com?wp03',
			'source': 'yahoo_tw_homepage_hp_cm_ron3',
			'Channel': 'DS'
		}, {
			'ctxtUrl': 'tw.yahoo.com?wp04',
			'source': 'yahoo_tw_homepage_hp_cm_ron4',
			'Channel': 'DS'
		}, {
			'ctxtUrl': 'tw.yahoo.com?wp05',
			'source': 'yahoo_tw_homepage_hp_cm_ron5',
			'Channel': 'DS'
		}, {
			'ctxtUrl': 'tw.yahoo.com?wp06',
			'source': 'yahoo_tw_homepage_hp_cm_ron6',
			'Channel': 'DS'
		}, {
			'ctxtUrl': 'tw.yahoo.com?wp07',
			'source': 'yahoo_tw_homepage_hp_cm_ron7',
			'Channel': 'SEM'
		}, {
			'ctxtUrl': 'tw.yahoo.com?wp08',
			'source': 'yahoo_tw_homepage_hp_cm_ron8',
			'Channel': 'SEM'
		}, {
			'ctxtUrl': 'tw.yahoo.com?wp09',
			'source': 'yahoo_tw_homepage_hp_cm_ron9',
			'Channel': 'OLS'
		}, {
			'ctxtUrl': 'tw.yahoo.com?wp10',
			'source': 'yahoo_tw_homepage_hp_cm_ron10',
			'Channel': 'OLS'
		}
	];
	
	var backfill = [
		{
			'ctxtUrl': 'http://tw.yahoo.com?wp',
			'source': 'yahoo_tw_homepage_beta_cm_ron',
			'Channel': 'DS'
		}
	];
	
	if ( typeof (window.YAHOO) == 'undefined') {
		window.YAHOO = {};
	}
	
	if ( typeof (window.YAHOO.YSM) == 'undefined') {
		window.YAHOO.YSM = {};
	}
	
	window.YAHOO.YSM.cmconfig = cmconfig;
	window.YAHOO.YSM.params = params;
	window.YAHOO.YSM.backfill = backfill;
})(window);