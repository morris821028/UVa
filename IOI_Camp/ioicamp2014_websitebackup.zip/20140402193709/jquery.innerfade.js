// =========================================================

// jquery.innerfade.js

// Datum: 2007-01-29
// Firma: Medienfreunde Hofmann & Baldes GbR
// Autor: Torsten Baldes
// Mail: t.baldes@medienfreunde.com
// Web: http://medienfreunde.com

// based on the work of Matt Oakes http://portfolio.gizone.co.uk/applications/slideshow/

// =========================================================
var selection = 1;
var pressStop = false;
var pickFlag = false ;
var pickNew = 0;
var currentTime = 1;
var targetTime = 55;
var pressStart = false;
(function($) {

$.fn.innerfade = function(options) {

	this.each(function(){ 	
		
		var settings = {
			animationtype: 'fade',
			speed: 'normal',
			timeout: 4000,
			type: 'sequence',
			containerheight: 'auto',
			runningclass: 'innerfade'
		};
		
		if(options)
			$.extend(settings, options);
		
		var elements = $(this).children();
		if (elements.length > 0) {
		
			$(this).css('position', 'relative');
	
			$(this).css('height', settings.containerheight);
			$(this).addClass(settings.runningclass);
			
			for ( var i = 0; i < elements.length; i++ ) {
				$(elements[i]).css('z-index', String(elements.length-i)).css('position', 'absolute');
				$(elements[i]).hide();
			};
		
			if ( settings.type == 'sequence' ) {
				setTimeout(function(){
					$.innerfade.next(elements, settings, 1, 0);
				}, settings.timeout);
				$(elements[0]).show();
			} else if ( settings.type == 'random' ) {
				setTimeout(function(){
					do { current = Math.floor ( Math.random ( ) * ( elements.length ) ); } while ( current == 0 )
					$.innerfade.next(elements, settings, current, 0);
				}, settings.timeout);
				$(elements[0]).show();
			}	else {
				alert('type must either be \'sequence\' or \'random\'');
			}
			
		}
		
	});
};

$.innerfade = function() {}
$.innerfade.next = function (elements, settings, current, last) {
	if(currentTime==targetTime)
	{
		if(!pressStop){
			//change img
			changeImg(current);
		
			if ( settings.animationtype == 'slide' ) {
				$(elements[last]).slideUp(settings.speed, $(elements[current]).slideDown(settings.speed));
			} else if ( settings.animationtype == 'fade' ) {
				$(elements[last]).fadeOut(settings.speed);
				$(elements[current]).fadeIn(settings.speed);
			} else {
				alert('animationtype must either be \'slide\' or \'fade\'');
			};
			
			if ( settings.type == 'sequence' ) {
				if ( ( current + 1 ) < elements.length ) {
					current = current + 1;
					last = current - 1;
				} else {
					current = 0;
					last = elements.length - 1;
				};
			}	else if ( settings.type == 'random' ) {
				last = current;
				while (	current == last ) {
					current = Math.floor ( Math.random ( ) * ( elements.length ) );
				};
			}	else {
				alert('type must either be \'sequence\' or \'random\'');
			};
		}
		currentTime = 1;	
	}
	if(pickFlag)
	{
		current = pickNew;
		$(elements[last]).fadeOut(settings.speed);
		$(elements[current]).fadeIn(settings.speed);
		last = 	current;
		if ( ( current + 1 ) < elements.length )
			current = current + 1;
		else
			current = 0;
		pickFlag = false;
	}
	if(pressStart)
	{
		$(elements[last]).fadeOut(settings.speed);
		$(elements[current]).fadeIn(settings.speed);
		if ( ( current + 1 ) < elements.length )
		{
			current = current + 1;
			last = current - 1;
		}
		else
		{
			current = 0;
			last = elements.length - 1;
		}
		pressStart = false;
	}		
	currentTime = currentTime + 1;
	setTimeout((function(){$.innerfade.next(elements, settings, current, last);}), settings.timeout);
	
};
})(jQuery);


$(document).ready(
	function(){					
		$('#portfolio').innerfade({
			speed: 'slow',
			timeout: 100,
			type: 'sequence',
			containerheight: '100px'
		});
	});
	
function bannerStart()
{
	currentTime = 1;
	pickFlag = false;
	pressStop = false;
	pressStart = true;
}  
function bannerStop()
{               
	pressStop = true;
}
function pickNews(pickNew)
{
	bannerStop();
	this.pickNew = pickNew;
	pickFlag = true;
	
	//change img
	changeImg(pickNew);
}
function changeImg(img){
	for(var i=0;i<news_size;i++){
		$("#pointer_"+i).attr("src","/prog/homepage/img/news_point1.gif");
	}
	$("#pointer_"+img).attr("src","/prog/homepage/img/news_point2.gif");
}