$().ready(function() {	
	var device = navigator.userAgent.toLowerCase().match(/(android|windows phone)/);
	var isAndroid = (device == null) ? false : true;
	
	if(isAndroid){        	
		var size = $('a[id^="FeaturedSoftware_BoxLink"]').length;
		for(var i = 0 ; i < size ; i++){
			$('a[id^="FeaturedSoftware_BoxLink"]:eq(' + i + ')').removeAttr("href");
		}
		
		var size2 = $('div[id^="FeaturedSoftware_ProductName"]').length;
		for(var j = 0 ; j < size2 ; j++){
			$('div[id^="FeaturedSoftware_ProductName"]:eq(' + j + ')').unbind('click');
			$('h2[id^="FeaturedSoftware_ProductName_slogn"]:eq(' + j + ')').unbind('click');
		}
	}
	
	$('#example7 .kwicks').kwicks({
		max: 260,
		duration: 400,
		sticky: true
	});
});